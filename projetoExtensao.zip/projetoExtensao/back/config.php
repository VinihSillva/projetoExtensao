<?php
$name_server = 'localhost';
$username = 'root';
$password = '';
$db_name = 'agendamento';

$host = "localhost"; // Insira o nome do host do seu banco de dados
$usuario = "root"; // Insira o nome de usuário do seu banco de dados
$senha = ""; // Insira a senha do seu banco de dados
$banco = "contato"; // Insira o nome do seu banco de dados

