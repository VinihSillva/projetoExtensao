<?php
require 'conexao.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST["nome"];
    $data = $_POST["data"];
    $horario = $_POST["horario"];
    $barbeiro = $_POST["barbeiro"];
    $servicos = $_POST["servicos"];
    $descricao = $_POST["descricao"];
    $local = $_POST["local"];

    $dataFormatada = date("Y-m-d", strtotime($data));
    $horarioFormatado = date("Y-m-d H:i:s", strtotime($horario));

    $query = "INSERT INTO agendamento (usuário, Data, Horário, Barbeiros, Serviços, Local, Observações) VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = mysqli_prepare($conn, $query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "sssssss", $nome, $dataFormatada, $horarioFormatado, $barbeiro, $servicos, $local, $descricao);

        mysqli_stmt_execute($stmt);

        mysqli_stmt_close($stmt);

        echo "Agendamento salvo com sucesso!";
    } else {
        echo "Erro ao preparar a consulta: " . mysqli_error($conn);
    }

    mysqli_close($conn);
}
