<?php

require 'conexao.php';



// Criar conexão
$conn = mysqli_connect($host, $usuario, $senha, $banco);

// Verificar a conexão
if (!$conn) {
    die("Falha na conexão: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $telefone = $_POST["telefone"];
    $mensagem = $_POST["mensagem"];

    $query = "INSERT INTO mensagens (nome, email, telefone, mensagem) VALUES (?, ?, ?, ?)";

    $stmt = mysqli_prepare($conn, $query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ssss", $nome, $email, $telefone, $mensagem);

        mysqli_stmt_execute($stmt);

        mysqli_stmt_close($stmt);

        echo "Mensagem salva com sucesso!";
    } else {
        echo "Erro ao enviar mensagem: " . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>