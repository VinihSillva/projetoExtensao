<?php
require 'config.php';

$conn = mysqli_connect($name_server, $username, $password, $db_name);
